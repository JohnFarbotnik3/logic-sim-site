import{a as t}from"../chunks/entry.NTNh6XxM.js";export{t as start};
