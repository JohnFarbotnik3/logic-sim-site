import{a as t}from"../chunks/entry.CWIt9b4D.js";export{t as start};
