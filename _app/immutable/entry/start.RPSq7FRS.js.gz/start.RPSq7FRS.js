import{a as t}from"../chunks/entry.CcvMCiRj.js";export{t as start};
